---
name: Apex Academic Core
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#45464d'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#76777d'
  outline-variant: '#c6c6cd'
  surface-tint: '#565e74'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#131b2e'
  on-primary-container: '#7c839b'
  inverse-primary: '#bec6e0'
  secondary: '#4b41e1'
  on-secondary: '#ffffff'
  secondary-container: '#645efb'
  on-secondary-container: '#fffbff'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#001d31'
  on-tertiary-container: '#188ace'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dae2fd'
  primary-fixed-dim: '#bec6e0'
  on-primary-fixed: '#131b2e'
  on-primary-fixed-variant: '#3f465c'
  secondary-fixed: '#e2dfff'
  secondary-fixed-dim: '#c3c0ff'
  on-secondary-fixed: '#0f0069'
  on-secondary-fixed-variant: '#3323cc'
  tertiary-fixed: '#cce5ff'
  tertiary-fixed-dim: '#93ccff'
  on-tertiary-fixed: '#001d31'
  on-tertiary-fixed-variant: '#004b73'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display-hero:
    fontFamily: Plus Jakarta Sans
    fontSize: 56px
    fontWeight: '800'
    lineHeight: 64px
    letterSpacing: -0.03em
  display-hero-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '800'
    lineHeight: 44px
    letterSpacing: -0.025em
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.025em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
    letterSpacing: -0.005em
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  label-code-lg:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: -0.01em
  label-code-sm:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-sm: 1rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system establishes an elite, forward-looking visual identity tailored for modern research and education in information and computing technologies. It balances the timeless authority of world-renowned academic institutions with the velocity and precision of global tech leaders. 

### Aesthetic Philosophy
The system combines **Corporate / Modern refinement** with targeted **Glassmorphism and crisp structural layering**. Visual weight relies on immaculate typography, deep oceanic slate backdrops contrasted against luminous crystalline cards, hairline borders, and disciplined architectural whitespace.

### Target Audience & Emotional Impact
- **Audience:** Global computer science candidates, engineering researchers, academic faculties, and institutional enterprise partners.
- **Tone & Mood:** Authoritative, intellectually ambitious, impeccably organized, and mathematically precise. The interface instills trust, academic rigor, and state-of-the-art technological competence.

## Colors

The color system structures hierarchy through high-contrast structural values, grounding the experience in deep tech navy while directing intentional focus via luminous indigo and electric sky blue.

### Core Architecture
- **Primary Canvas & Structural Depth:** `#0F172A` (Navy 900) anchors authoritative headers, primary navigational elements, and strong brand moments. `#1E293B` (Navy 800) supports secondary surfaces and modal foundations.
- **Academic Core (Secondary):** `#4F46E5` (Indigo 600) drives primary callouts, focus rings, primary interactive anchors, and institutional commitments. `#4338CA` (Indigo 700) is reserved for active click states and dense informational headers.
- **Technical Accents (Tertiary):** `#0284C7` (Sky 600) and `#0EA5E9` (Sky 500) serve as technical callouts, highlighting research metrics, interactive code tokens, and active progress telemetry.
- **Surface Foundations:** Background canvas runs on `#F8FAFC` (Slate 50), surfaced cards utilize pure `#FFFFFF` (White), and dividing boundaries use `#E2E8F0` (Slate 200).
- **Text & Readability:** Headings default to `#0F172A` for uncompromising contrast. Body copy is maintained at `#475569` (Slate 600) for prolonged reading comfort without optical glare.

### Semantic Triage
- **Approved / Verified / Success:** `#10B981` (Emerald 500)
- **Pending / Action Required / In Review:** `#F59E0B` (Amber 500)
- **Deficient / Rejected / Critical Alert:** `#F43F5E` (Rose 500)

## Typography

The typographic system utilizes **Plus Jakarta Sans** across display, structural, and narrative levels to convey confidence, geometric harmony, and forward momentum. Technical markers, student serial records, and algorithmic models are punctuated by **JetBrains Mono**.

### Rules & Optical Guidance
- **Display & Section Titles:** Display and headline levels must maintain negative letter tracking (-0.01em to -0.03em) to eliminate loose spacing in large letterforms and project architectural solidity.
- **Monospace Integration:** Monospace styling is applied to technical labels, course codes (`AIT-CS-2025`), academic terms, verification hashes, and metadata chips.
- **Line Length:** Body copy containers should enforce an optical maximum width of 68 characters (~650px) to sustain elite editorial standards.

## Layout & Spacing

The layout relies on a mathematical 8pt linear rhythm configured via a responsive fluid grid system designed for data clarity and administrative workflow density.

### Breakpoint Structure
- **Mobile (< 768px):** 4-column layout, dynamic content stacking, `margin-mobile` (16px), and `gutter-sm` (16px). Secondary toolbars and filters collapse into floating modal sheets.
- **Tablet (768px - 1023px):** 8-column layout, 24px margins, standard `gutter` (24px). Dual-pane configurations for course modules and admissions checklists.
- **Desktop (≥ 1024px):** 12-column layout with a maximum container boundary of 1440px. Margin scales to `margin` (32px), with fixed sidebars reserved for degree management, telemetry, and curriculum trees.

### Rhythmic Discipline
Margins and structural card paddings scale predictably: form groups leverage `space-md` (16px), major module containers use `space-lg` (24px) to `space-xl` (40px), and nested table headers enforce `space-sm` (8px) internal bounds.

## Elevation & Depth

Visual hierarchy uses crisp boundary definitions, subtle backdrop filtering, and multi-layered translucent shadows.

### Atmospheric Planes
- **Ground Floor (Base Canvas):** Solid `#F8FAFC`. Zero elevation, non-interactive foundation.
- **Level 1 (Cards & Data Containers):** Pure `#FFFFFF` resting over base canvas, defined by a 1px solid border of `#E2E8F0` and an ambient drop shadow: `0 1px 3px rgba(15, 23, 42, 0.04), 0 1px 2px rgba(15, 23, 42, 0.02)`.
- **Level 2 (Active Cards & Floating Headers):** Elevated interactive elements receive a deeper compound shadow: `0 10px 25px -5px rgba(15, 23, 42, 0.06), 0 8px 10px -6px rgba(15, 23, 42, 0.04)`.
- **Level 3 (Navigation Bars & Sticky Shelves):** Translucent glass composition using `#FFFFFF` at 85% opacity paired with `backdrop-filter: blur(12px)` and a bottom border of `rgba(226, 232, 240, 0.8)`.
- **Level 4 (Modals & Overlays):** Deep ambient diffusion: `0 25px 50px -12px rgba(15, 23, 42, 0.18)` positioned over a backdrop curtain of `#0F172A` at 40% opacity with `backdrop-filter: blur(4px)`.

## Shapes

The design system implements a controlled shape vocabulary with roundedness level 2 (0.5rem base radius), blending contemporary software design with academic order.

### Shape Hierarchy
- **Standard Radius (`rounded-md`, 0.5rem / 8px):** Applied to interactive utility inputs, standard buttons, dropdown menus, and standard alert boxes.
- **Large Radius (`rounded-lg`, 1rem / 16px):** Dedicated to primary application cards, dashboard module frames, and data grid wrappers.
- **Extra Large Radius (`rounded-xl`, 1.5rem / 24px):** Reserved exclusively for hero showcase banners, comprehensive modular groupings, and primary dialog containers.
- **Pill Radius (`rounded-full`, 9999px):** Applied strictly to semantic status indicators, verification tags, and step-indicator circles.

## Components

### Buttons
- **Primary:** Deep Slate `#0F172A` base with white text, or Academic Indigo `#4F46E5` with white text for critical workflow progression. Height: 44px (Desktop), font-weight: 600, border-radius: 8px. Hover transition to `#1E293B` or `#4338CA` with subtle translation (`translateY(-0.5px)`). Focus ring: 2px solid `#4F46E5` with 2px offset.
- **Secondary / Ghost:** Pure white `#FFFFFF` with 1px border `#E2E8F0`, slate text `#1E293B`. Hover shifts surface to `#F1F5F9`.
- **Destructive:** Subtle rose wash background (`#FFF1F2`) paired with a `#F43F5E` label and border.

### Status Chips & Badges
- Constructed with pill geometry (`rounded-full`) using monospace typography (`label-code-sm`).
- **Approved / Active:** `#ECFDF5` background, `#065F46` label, with a 6px solid `#10B981` radial dot prefix.
- **Pending / In Review:** `#FFFBEB` background, `#92400E` label, paired with a `#F59E0B` indicator dot.
- **Action Required / Deficient:** `#FFF1F2` background, `#9F1239` label, paired with a `#F43F5E` indicator dot.

### Inputs & Form Elements
- **Height & Field Spec:** 42px field height with 12px horizontal padding. Border: 1px `#CBD5E1`. Background: `#FFFFFF`. Typography: `body-md`. Placeholder text: `#94A3B8`.
- **Focus State:** Active input outline glows via 2px `#4F46E5` ring with zero border collapse.
- **Selection Controls (Checkboxes & Radios):** Custom 18px boxes with 4px inner border-radius. Active state filled with `#4F46E5` featuring a white geometric checkmark.

### Stepper Controls & Application Trackers
- Horizontal sequenced node chains. Completed stages use filled `#4F46E5` circular badges containing verified check icons. Active current steps feature a dual-ring target (`#4F46E5` center with a 4px soft `#EEF2FF` halo). Future stages use neutral `#E2E8F0` badges with `#64748B` numerical values. Connecting bridges maintain 2px weight, transitioning from indigo to slate lines.

### Cards & Content Containers
- Border: 1px continuous hairline `#E2E8F0`. Surface: `#FFFFFF`. Radius: `1rem` (`rounded-lg`).
- Modular Header division: Headers feature an optional 1px horizontal border separator `#F1F5F9` keeping administrative metadata neatly isolated from operational forms and tables.

### Code & Credential Blocks
- Dedicated wrappers for student identifiers, API keys, and course codes. Rendered in JetBrains Mono over `#F8FAFC` backgrounds with 1px dashed borders of `#CBD5E1`, equipped with 1-click clipboard utility icons.